import { NextFunction, Request, Response } from "express";
import jwt from "jsonwebtoken";

export interface AuthRequest extends Request{
    userId?:number;
    userEmail?:string;
}

export const authenticate = (req:AuthRequest, res:Response, next:NextFunction)=>{
    try{

        const authHeader = req.headers.authorization;
        if(!authHeader || !authHeader.startsWith('Bearer ')){
            return res.status(401).json({message:"No token provided"})
        }

        const token = authHeader.split(" ")[1];

        const decoded = jwt.verify(token , process.env.JWT_SECRET as string) as {
            userId:number;
            email:string;
        };


        req.userId = decoded.userId;
        req.userEmail = decoded.email


        next()

    }catch(error){
        return res.status(401).json({message:"Invalid or expired token"})
    }
}