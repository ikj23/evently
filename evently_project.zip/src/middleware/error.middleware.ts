import { NextFunction, Request, Response } from "express";

export const errorHandler = (
    error:any,
    req:Request,
    res:Response,
    next: NextFunction
) => {
    console.error("error" , error.message);

    return res.status(error.status).json({"error":error.message})

}