import { DataSource } from 'typeorm';
import dotenv from 'dotenv';
import { User } from './entity/User';
import { Event } from './entity/Event';
import { Booking } from './entity/Booking';
import { TicketTier } from './entity/TicketTier';

dotenv.config();

export const AppDataSource = new DataSource({
  type: 'better-sqlite3',
  database: process.env.DB_PATH || './database.db',
  synchronize: false,
  logging: true,
  entities:[User,Event,Booking,TicketTier],
  // entities: ['src/entity/*.ts'],
   migrations: [__dirname + '/migrations/*.ts'],
  migrationsTableName: 'migrations',
});