import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne, OneToMany, JoinColumn } from 'typeorm';
import { Event } from './Event';
import { Booking } from './Booking';


@Entity()
export class TicketTier {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column('decimal', { precision: 10, scale: 2 })
  price: number;

  @Column()
  totalCapacity: number;

  @Column()
  availableSeats: number;

  @CreateDateColumn()
  createdAt: Date;

  @Column()
  eventId: number;

  @ManyToOne(() => Event, (event) => event.tiers)
  @JoinColumn({ name: 'eventId' })
  event: Event;

  @OneToMany(() => Booking, (booking) => booking.tier)
  bookings: Booking[];
}