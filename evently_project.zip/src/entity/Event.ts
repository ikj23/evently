import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from "typeorm";

import { TicketTier } from "./TicketTier";
import { User } from "./User";

export type EventStatus = 'draft' | 'published' | 'cancelled';

@Entity()
export class Event {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  title: string;

  @Column({ type: 'text' })
  description: string;

  @Column()
  venue: string;

  @Column()
  city: string;

  @Column()
  startDate: Date;

   @Column()
  endDate: Date;

  @Column({ default: 'draft' })
  status: EventStatus;

  @CreateDateColumn()
  createdAt: Date;

  @Column()
  organizerId: number;

  @ManyToOne(() => User, (user) => user.events)
  @JoinColumn({ name: 'organizerId' })
  organizer: User;

  @OneToMany(() => TicketTier, (tier) => tier.event)
  tiers: TicketTier[];
}