import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { User } from './User';
import { TicketTier } from './TicketTier';

export type BookingStatus = 'active' | 'cancelled';

@Entity()
export class Booking {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  quantity: number;

  @Column('decimal', { precision: 10, scale: 2 })
  priceAtBooking: number;

  @Column({ default: 'active' })
  status: BookingStatus;

  @CreateDateColumn()
  createdAt: Date;

  @Column()
  userId: number;

  @Column()
  tierId: number;

  @ManyToOne(() => User, (user) => user.bookings)
  @JoinColumn({ name: 'userId' })
  user: User;

  @ManyToOne(() => TicketTier, (tier) => tier.bookings)
  @JoinColumn({ name: 'tierId' })
  tier: TicketTier;
}
