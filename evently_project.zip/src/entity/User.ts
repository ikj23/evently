import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { Event } from "./Event";
import { Booking } from "./Booking";

@Entity()
export class User {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    name: string;

    @Column({ unique: true })
    email: string

    @Column()
    password: string

    @CreateDateColumn()
    createdAt: Date;

    @OneToMany(() => Event, (event) => event.organizer)
    events: Event[];

    @OneToMany(() => Booking, (booking) => booking.user)
    bookings: Booking[];
}