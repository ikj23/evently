import { Router } from 'express';
import {
  createEvent,
  getAllEvent,
  getEventById,
  updateEvent,
  cancelEvent,
} from '../controllers/event.controller';
import { authenticate } from '../middleware/auth.middleware';

const Eventrouter = Router();


Eventrouter.post('/', authenticate, createEvent);
Eventrouter.get('/', authenticate, getAllEvent);
Eventrouter.get('/:id', authenticate, getEventById);
Eventrouter.put('/:id', authenticate, updateEvent);
Eventrouter.patch('/:id/cancel', authenticate, cancelEvent);

export default Eventrouter;