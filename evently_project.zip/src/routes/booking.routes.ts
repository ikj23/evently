import { Router } from 'express';
import {
  createBooking,
  getMyBookings,
  cancelBooking,
} from '../controllers/booking.controller';
import { authenticate } from '../middleware/auth.middleware';

const bookingrouter = Router();

bookingrouter.post('/', authenticate, createBooking);
bookingrouter.get('/my', authenticate, getMyBookings);
bookingrouter.patch('/:id/cancel', authenticate, cancelBooking);

export default bookingrouter;