import { Router } from 'express';
import {
  addTier,
  getTiersByEvent,
  updateTier,
  deleteTier,
} from '../controllers/tier.controller';
import { authenticate } from '../middleware/auth.middleware';

const Tierrouter = Router({ mergeParams: true }); // ← important!

Tierrouter.post('/', authenticate, addTier);
Tierrouter.get('/', authenticate, getTiersByEvent);
Tierrouter.put('/:tierId', authenticate, updateTier);
Tierrouter.delete('/:tierId', authenticate, deleteTier);

export default Tierrouter;