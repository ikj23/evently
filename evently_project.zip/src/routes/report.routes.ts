import { Router } from 'express';
import {
  getRevenueSummary,
  getAttendanceSummary,
  getTopEvents,
  getEventTierBreakdown,
  getAnalytics,
} from '../controllers/report.controller';
import { authenticate } from '../middleware/auth.middleware';

const Reportrouter = Router();

Reportrouter.get('/revenue', authenticate, getRevenueSummary);
Reportrouter.get('/attendance', authenticate, getAttendanceSummary);
Reportrouter.get('/top-events', authenticate, getTopEvents);
Reportrouter.get('/events/:eventId/tiers', authenticate, getEventTierBreakdown);
Reportrouter.get('/analytics', authenticate, getAnalytics);

export default Reportrouter;