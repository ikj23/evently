import 'reflect-metadata';
import express from 'express';
import dotenv from 'dotenv';
import { AppDataSource } from './data.source';
import { errorHandler } from './middleware/error.middleware';
import Authrouter from './routes/auth.routes';
import Eventrouter from './routes/event.routes';
import Tierrouter from './routes/tier.routes';
import bookingrouter from './routes/booking.routes';
import Reportrouter from './routes/report.routes';

dotenv.config();
const app = express();
app.use(express.json());

app.use('/auth' , Authrouter)
app.use('/events', Eventrouter);
app.use('/events/:eventId/tiers', Tierrouter);
app.use('/bookings', bookingrouter);
app.use('/reports', Reportrouter);

app.use(errorHandler)

const PORT = process.env.PORT || 3000;

AppDataSource.initialize()
  .then(() => {
    console.log('✅ Database connected!');
    app.listen(PORT, () => {
      console.log(`🚀 Server running on http://localhost:${PORT}`);
    });
  })
  .catch((error) => {
    console.error('❌ Database connection failed:', error);
  });