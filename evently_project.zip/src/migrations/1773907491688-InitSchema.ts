import { MigrationInterface, QueryRunner } from "typeorm";

export class InitSchema1773907491688 implements MigrationInterface {
    name = 'InitSchema1773907491688'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "booking" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "quantity" integer NOT NULL, "priceAtBooking" decimal(10,2) NOT NULL, "status" varchar NOT NULL DEFAULT ('active'), "createdAt" datetime NOT NULL DEFAULT (datetime('now')), "userId" integer NOT NULL, "tierId" integer NOT NULL)`);
        await queryRunner.query(`CREATE TABLE "ticket_tier" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "name" varchar NOT NULL, "price" decimal(10,2) NOT NULL, "totalCapacity" integer NOT NULL, "availableSeats" integer NOT NULL, "createdAt" datetime NOT NULL DEFAULT (datetime('now')), "eventId" integer NOT NULL)`);
        await queryRunner.query(`CREATE TABLE "event" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "title" varchar NOT NULL, "description" text NOT NULL, "venue" varchar NOT NULL, "city" varchar NOT NULL, "startDate" datetime NOT NULL, "endDate" datetime NOT NULL, "status" varchar NOT NULL DEFAULT ('draft'), "createdAt" datetime NOT NULL DEFAULT (datetime('now')), "organizerId" integer NOT NULL)`);
        await queryRunner.query(`CREATE TABLE "user" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "name" varchar NOT NULL, "email" varchar NOT NULL, "password" varchar NOT NULL, "createdAt" datetime NOT NULL DEFAULT (datetime('now')), CONSTRAINT "UQ_e12875dfb3b1d92d7d7c5377e22" UNIQUE ("email"))`);
        await queryRunner.query(`CREATE TABLE "temporary_booking" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "quantity" integer NOT NULL, "priceAtBooking" decimal(10,2) NOT NULL, "status" varchar NOT NULL DEFAULT ('active'), "createdAt" datetime NOT NULL DEFAULT (datetime('now')), "userId" integer NOT NULL, "tierId" integer NOT NULL, CONSTRAINT "FK_336b3f4a235460dc93645fbf222" FOREIGN KEY ("userId") REFERENCES "user" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION, CONSTRAINT "FK_641f805db21284d9746cc6dd72d" FOREIGN KEY ("tierId") REFERENCES "ticket_tier" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION)`);
        await queryRunner.query(`INSERT INTO "temporary_booking"("id", "quantity", "priceAtBooking", "status", "createdAt", "userId", "tierId") SELECT "id", "quantity", "priceAtBooking", "status", "createdAt", "userId", "tierId" FROM "booking"`);
        await queryRunner.query(`DROP TABLE "booking"`);
        await queryRunner.query(`ALTER TABLE "temporary_booking" RENAME TO "booking"`);
        await queryRunner.query(`CREATE TABLE "temporary_ticket_tier" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "name" varchar NOT NULL, "price" decimal(10,2) NOT NULL, "totalCapacity" integer NOT NULL, "availableSeats" integer NOT NULL, "createdAt" datetime NOT NULL DEFAULT (datetime('now')), "eventId" integer NOT NULL, CONSTRAINT "FK_f8477dfcb7c6e53472b7674a898" FOREIGN KEY ("eventId") REFERENCES "event" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION)`);
        await queryRunner.query(`INSERT INTO "temporary_ticket_tier"("id", "name", "price", "totalCapacity", "availableSeats", "createdAt", "eventId") SELECT "id", "name", "price", "totalCapacity", "availableSeats", "createdAt", "eventId" FROM "ticket_tier"`);
        await queryRunner.query(`DROP TABLE "ticket_tier"`);
        await queryRunner.query(`ALTER TABLE "temporary_ticket_tier" RENAME TO "ticket_tier"`);
        await queryRunner.query(`CREATE TABLE "temporary_event" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "title" varchar NOT NULL, "description" text NOT NULL, "venue" varchar NOT NULL, "city" varchar NOT NULL, "startDate" datetime NOT NULL, "endDate" datetime NOT NULL, "status" varchar NOT NULL DEFAULT ('draft'), "createdAt" datetime NOT NULL DEFAULT (datetime('now')), "organizerId" integer NOT NULL, CONSTRAINT "FK_19642e6a244b4885e14eab0fdc0" FOREIGN KEY ("organizerId") REFERENCES "user" ("id") ON DELETE NO ACTION ON UPDATE NO ACTION)`);
        await queryRunner.query(`INSERT INTO "temporary_event"("id", "title", "description", "venue", "city", "startDate", "endDate", "status", "createdAt", "organizerId") SELECT "id", "title", "description", "venue", "city", "startDate", "endDate", "status", "createdAt", "organizerId" FROM "event"`);
        await queryRunner.query(`DROP TABLE "event"`);
        await queryRunner.query(`ALTER TABLE "temporary_event" RENAME TO "event"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "event" RENAME TO "temporary_event"`);
        await queryRunner.query(`CREATE TABLE "event" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "title" varchar NOT NULL, "description" text NOT NULL, "venue" varchar NOT NULL, "city" varchar NOT NULL, "startDate" datetime NOT NULL, "endDate" datetime NOT NULL, "status" varchar NOT NULL DEFAULT ('draft'), "createdAt" datetime NOT NULL DEFAULT (datetime('now')), "organizerId" integer NOT NULL)`);
        await queryRunner.query(`INSERT INTO "event"("id", "title", "description", "venue", "city", "startDate", "endDate", "status", "createdAt", "organizerId") SELECT "id", "title", "description", "venue", "city", "startDate", "endDate", "status", "createdAt", "organizerId" FROM "temporary_event"`);
        await queryRunner.query(`DROP TABLE "temporary_event"`);
        await queryRunner.query(`ALTER TABLE "ticket_tier" RENAME TO "temporary_ticket_tier"`);
        await queryRunner.query(`CREATE TABLE "ticket_tier" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "name" varchar NOT NULL, "price" decimal(10,2) NOT NULL, "totalCapacity" integer NOT NULL, "availableSeats" integer NOT NULL, "createdAt" datetime NOT NULL DEFAULT (datetime('now')), "eventId" integer NOT NULL)`);
        await queryRunner.query(`INSERT INTO "ticket_tier"("id", "name", "price", "totalCapacity", "availableSeats", "createdAt", "eventId") SELECT "id", "name", "price", "totalCapacity", "availableSeats", "createdAt", "eventId" FROM "temporary_ticket_tier"`);
        await queryRunner.query(`DROP TABLE "temporary_ticket_tier"`);
        await queryRunner.query(`ALTER TABLE "booking" RENAME TO "temporary_booking"`);
        await queryRunner.query(`CREATE TABLE "booking" ("id" integer PRIMARY KEY AUTOINCREMENT NOT NULL, "quantity" integer NOT NULL, "priceAtBooking" decimal(10,2) NOT NULL, "status" varchar NOT NULL DEFAULT ('active'), "createdAt" datetime NOT NULL DEFAULT (datetime('now')), "userId" integer NOT NULL, "tierId" integer NOT NULL)`);
        await queryRunner.query(`INSERT INTO "booking"("id", "quantity", "priceAtBooking", "status", "createdAt", "userId", "tierId") SELECT "id", "quantity", "priceAtBooking", "status", "createdAt", "userId", "tierId" FROM "temporary_booking"`);
        await queryRunner.query(`DROP TABLE "temporary_booking"`);
        await queryRunner.query(`DROP TABLE "user"`);
        await queryRunner.query(`DROP TABLE "event"`);
        await queryRunner.query(`DROP TABLE "ticket_tier"`);
        await queryRunner.query(`DROP TABLE "booking"`);
    }

}
