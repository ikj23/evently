import { Request, Response, NextFunction } from 'express';
import { AppDataSource } from '../data.source';
import { TicketTier } from '../entity/TicketTier';
import { Event } from '../entity/Event';
import { AuthRequest } from '../middleware/auth.middleware';
import { Booking } from '../entity/Booking';

const tierRepo = AppDataSource.getRepository(TicketTier);
const eventRepo = AppDataSource.getRepository(Event);
const bookingRepo = AppDataSource.getRepository(Booking);

// ─── ADD TIER ────────────────────────────────────────────
export const addTier = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const { eventId } = req.params;
    const { name, price, totalCapacity } = req.body;

    // 1. Validate fields
    if (!name || price === undefined || !totalCapacity) {
      return res.status(400).json({ message: 'name, price and totalCapacity are required' });
    }

    if (price < 0) {
      return res.status(400).json({ message: 'Price cannot be negative' });
    }

    if (totalCapacity <= 0) {
      return res.status(400).json({ message: 'totalCapacity must be greater than 0' });
    }

    // 2. Find the event
    const event = await eventRepo.findOne({ where: { id: Number(eventId) } });
    if (!event) {
      return res.status(404).json({ message: 'Event not found' });
    }

    // 3. Only organizer can add tiers
    if (event.organizerId !== req.userId) {
      return res.status(403).json({ message: 'Only the organizer can add tiers' });
    }

    // 4. Cannot add tiers to cancelled event
    if (event.status === 'cancelled') {
      return res.status(400).json({ message: 'Cannot add tiers to a cancelled event' });
    }

    // 5. Create tier
    // availableSeats starts equal to totalCapacity
    const tier = tierRepo.create({
      name,
      price,
      totalCapacity,
      availableSeats: totalCapacity,  // ← starts full
      eventId: Number(eventId),
    });

    await tierRepo.save(tier);

    return res.status(201).json({
      message: 'Tier added successfully',
      tier,
    });

  } catch (error) {
    next(error);
  }
};

// ─── GET ALL TIERS ───────────────────────────────────────
export const getTiersByEvent = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const { eventId } = req.params;

    // 1. Check event exists
    const event = await eventRepo.findOne({ where: { id: Number(eventId) } });
    if (!event) {
      return res.status(404).json({ message: 'Event not found' });
    }

    // 2. Get all tiers for this event
    const tiers = await tierRepo.find({
      where: { eventId: Number(eventId) },
      order: { price: 'ASC' },
    });

    return res.status(200).json({
      message: 'Tiers fetched successfully',
      count: tiers.length,
      tiers,
    });

  } catch (error) {
    next(error);
  }
};

// ─── UPDATE TIER ─────────────────────────────────────────
export const updateTier = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const { eventId, tierId } = req.params;
    const { name, price, totalCapacity } = req.body;

    // 1. Find the event
    const event = await eventRepo.findOne({ where: { id: Number(eventId) } });
    if (!event) {
      return res.status(404).json({ message: 'Event not found' });
    }

    // 2. Only organizer can update tiers
    if (event.organizerId !== req.userId) {
      return res.status(403).json({ message: 'Only the organizer can update tiers' });
    }

    // 3. Find the tier
    const tier = await tierRepo.findOne({
      where: { id: Number(tierId), eventId: Number(eventId) },
    });
    if (!tier) {
      return res.status(404).json({ message: 'Tier not found' });
    }

    // 4. Check if any tickets have been sold for this tier
    const soldTickets = await bookingRepo.count({
      where: { tierId: Number(tierId), status: 'active' },
    });

    if (soldTickets > 0) {
      return res.status(400).json({
        message: 'Cannot edit tier after tickets have been sold',
        soldTickets,
      });
    }

    // 5. Validate if provided
    if (price !== undefined && price < 0) {
      return res.status(400).json({ message: 'Price cannot be negative' });
    }

    if (totalCapacity !== undefined && totalCapacity <= 0) {
      return res.status(400).json({ message: 'totalCapacity must be greater than 0' });
    }

    // 6. Update only provided fields
    if (name) tier.name = name;
    if (price !== undefined) tier.price = price;
    if (totalCapacity !== undefined) {
      tier.totalCapacity = totalCapacity;
      tier.availableSeats = totalCapacity;  // reset since no tickets sold
    }

    await tierRepo.save(tier);

    return res.status(200).json({
      message: 'Tier updated successfully',
      tier,
    });

  } catch (error) {
    next(error);
  }
};

// ─── DELETE TIER ─────────────────────────────────────────
export const deleteTier = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const { eventId, tierId } = req.params;

    // 1. Find the event
    const event = await eventRepo.findOne({ where: { id: Number(eventId) } });
    if (!event) {
      return res.status(404).json({ message: 'Event not found' });
    }

    // 2. Only organizer can delete tiers
    if (event.organizerId !== req.userId) {
      return res.status(403).json({ message: 'Only the organizer can delete tiers' });
    }

    // 3. Find the tier
    const tier = await tierRepo.findOne({
      where: { id: Number(tierId), eventId: Number(eventId) },
    });
    if (!tier) {
      return res.status(404).json({ message: 'Tier not found' });
    }

    // 4. Check if any tickets have been sold
    const soldTickets = await bookingRepo.count({
      where: { tierId: Number(tierId), status: 'active' },
    });

    if (soldTickets > 0) {
      return res.status(400).json({
        message: 'Cannot delete tier after tickets have been sold',
        soldTickets,
      });
    }

    // 5. Delete the tier
    await tierRepo.remove(tier);

    return res.status(200).json({
      message: 'Tier deleted successfully',
    });

  } catch (error) {
    next(error);
  }
};