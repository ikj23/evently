import { NextFunction, Request, Response } from "express";
import { AppDataSource } from "../data.source";
import { User } from "../entity/User";
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { JsonContains } from "typeorm";

const userRepository = AppDataSource.getRepository(User)

export const register = async (req:Request , res:Response , next:NextFunction) => {
    try{
        const {name, email, password} = req.body;

        if(!name || !email || !password){
            return res.status(400).json({message:"name, email, password are required"})
        }

        const existingUser = await userRepository.findOne({where:{email}})

        if(existingUser){
            return res.status(400).json({message:"email already registered"})
        }

        const hashedpwd = await bcrypt.hash(password,10)

        const user = userRepository.create({
            name,
            email,
            password: hashedpwd
        });
        await userRepository.save(user)

        return res.status(201).json({
            message:"user registered successfully",
            user:{id:user.id , name:user.name , email:user.email}
        });
    }catch (error){
        next(error)
    }
}

export const login = async (req:Request, res:Response, next:NextFunction) => {
    try{
        const {email , password} = req.body;

        if (!email || !password) {
            return res.status(400).json({message:"Email and password are required"})
        }


        const user = await userRepository.findOne({where: {email}});
        if(!user){
            return res.status(401).json({message:"Invalid email or pwd"})
        }

        const isMatch = await bcrypt.compare(password,user.password);
        if(!isMatch){
            return res.status(401).json({message:"Invalid email or password"})
        }

        const token = jwt.sign(
            {userId:user.id, email:user.email},
            process.env.JWT_SECRET as string,
            {expiresIn: '7d'}
        );

        return res.status(200).json({
            message: 'Login successfull',
            token,
            user:{id:user.id, name:user.name, email:user.email} 
        })


    }catch(error){
        next(error)
    }
}