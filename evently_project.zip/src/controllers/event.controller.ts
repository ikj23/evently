import { NextFunction, Response } from "express";
import { AuthRequest } from "../middleware/auth.middleware";
import { AppDataSource } from "../data.source";
import { Event } from "../entity/Event";

const eventRepo = AppDataSource.getRepository(Event) 
export const createEvent = async(req:AuthRequest, res:Response, next:NextFunction) => {
    try{
        const {title , description, venue, city, startDate, endDate, status} =req.body


        if (!title || !description || !venue || !city || !startDate || !endDate) {
            return res.status(400).json({message:"all fields are required"})
        }

        const allowedStatus = ['draft' , 'published' , 'cancelled'];

        if (status && !allowedStatus.includes(status)) {
            return res.status(400).json({message:"Status mut be draft,published or cancelled"})
        }



        if (new Date(startDate) >= new Date(endDate)) {
            return res.status(400).json({message: "startDate mus be before endDAte"}) 
        }

        const event = eventRepo.create({
            title,
            description,
            venue,
            city,
            startDate: new Date(startDate),
            endDate: new Date(endDate),
            status: status || 'draft',
            organizerId:req.userId
        });

        await eventRepo.save(event)


        return res.status(201).json({
            message:'event created successfully'
        });


    }catch(error){
        next(error)
    }
}


export const getAllEvent = async (req:AuthRequest, res:Response, next:NextFunction) => {
    try{
        const events = await eventRepo.find({
            where: {status: 'published'},
            relations:['organizer' , 'tiers'],
            order: {startDate: 'ASC'},
        });


        const safeEvent = events.map(event => ({
            ...event,
            organizer:event.organizer
            ?{id:event.organizer.id, name: event.organizer.name, email:event.organizer.email} : null
        }));


        return res.status(200).json({
            message: 'events fetched successfully',
            count:safeEvent.length,
            events:safeEvent,
        });
    }catch(err){
        next(err)
    }
}



export const getEventById = async (req:AuthRequest, res:Response, next:NextFunction) => {
    try{
        const{id} = req.params;

        const event = await eventRepo.findOne({
            where: {id:Number(id)},
            relations: ['organizer' , 'tiers']
        });

        if(!event){
            return res.status(404).json({message:"Event not found"})
        }

        const safeEvent = {
            ...event,
            organizer:event.organizer
            ? {id:event.organizer.id, name:event.organizer.name , email:event.organizer.email}:null,
        }


        return res.status(200).json({
            message:"event fetched successfully",
            event:safeEvent
        });


    }catch(err){
        next(err)
    }
}




export const updateEvent = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;
    const { title, description, venue, city, startDate, endDate, status } = req.body;

    
    const event = await eventRepo.findOne({ where: { id: Number(id) } });
    if (!event) {
      return res.status(404).json({ message: 'Event not found' });
    }

    
    if (event.organizerId !== req.userId) {
      return res.status(403).json({ message: 'You are not authorized to update this event' });
    }

    
    if (event.status === 'cancelled') {
      return res.status(400).json({ message: 'Cannot update a cancelled event' });
    }

    
    const newStart = startDate ? new Date(startDate) : event.startDate;
    const newEnd = endDate ? new Date(endDate) : event.endDate;
    if (newStart >= newEnd) {
      return res.status(400).json({ message: 'startDate must be before endDate' });
    }

    
    const allowedStatuses = ['draft', 'published', 'cancelled'];
    if (status && !allowedStatuses.includes(status)) {
      return res.status(400).json({ message: 'Status must be draft, published or cancelled' });
    }

    
    if (title) event.title = title;
    if (description) event.description = description;
    if (venue) event.venue = venue;
    if (city) event.city = city;
    if (startDate) event.startDate = new Date(startDate);
    if (endDate) event.endDate = new Date(endDate);
    if (status) event.status = status;

    await eventRepo.save(event);

    return res.status(200).json({
      message: 'Event updated successfully',
      event,
    });

  } catch (error) {
    next(error);
  }
};


export const cancelEvent = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;

    
    const event = await eventRepo.findOne({
      where: { id: Number(id) },
      relations: ['tiers'],
    });

    if (!event) {
      return res.status(404).json({ message: 'Event not found' });
    }

    
    if (event.organizerId !== req.userId) {
      return res.status(403).json({ message: 'You are not authorized to cancel this event' });
    }

    
    if (event.status === 'cancelled') {
      return res.status(400).json({ message: 'Event is already cancelled' });
    }

    
    event.status = 'cancelled';

    
    if (event.tiers && event.tiers.length > 0) {
      const tierRepository = AppDataSource.getRepository('TicketTier');
      for (const tier of event.tiers) {
        await tierRepository.update(tier.id, { availableSeats: 0 });
      }
    }

    await eventRepo.save(event);

    return res.status(200).json({
      message: 'Event cancelled successfully',
      event,
    });

  } catch (error) {
    next(error);
  }
};

