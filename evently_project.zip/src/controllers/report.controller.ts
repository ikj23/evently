import { Response, NextFunction } from 'express';
import { AppDataSource } from '../data.source';
import { AuthRequest } from '../middleware/auth.middleware';
import { Booking } from '../entity/Booking';
import { Event } from '../entity/Event';
import { TicketTier } from '../entity/TicketTier';
import { User } from '../entity/User';

// ─── Q1 & Q11: REVENUE SUMMARY ───────────────────────────
// Q1:  Total revenue in January 2025
// Q11: Month over month revenue trend in 2025
export const getRevenueSummary = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const { startDate, endDate } = req.query;

    // Q11 — Month over month revenue for 2025
    const monthlyRevenue = await AppDataSource
      .createQueryBuilder(Booking, 'booking')
      .innerJoin('booking.tier', 'tier')
      .innerJoin('tier.event', 'event')
      .select("strftime('%Y-%m', event.startDate)", 'month')
      .addSelect('SUM(booking.priceAtBooking * booking.quantity)', 'totalRevenue')
      .addSelect('SUM(booking.quantity)', 'totalTicketsSold')
      .addSelect('COUNT(booking.id)', 'totalBookings')
      .where('booking.status = :status', { status: 'active' })
      .andWhere("strftime('%Y', event.startDate) = '2025'")
      .groupBy("strftime('%Y-%m', event.startDate)")
      .orderBy('month', 'ASC')
      .getRawMany();

    // Q1 — Filter by date range if provided
    let filteredRevenue = monthlyRevenue;
    if (startDate && endDate) {
      const revenueInRange = await AppDataSource
        .createQueryBuilder(Booking, 'booking')
        .innerJoin('booking.tier', 'tier')
        .innerJoin('tier.event', 'event')
        .select('SUM(booking.priceAtBooking * booking.quantity)', 'totalRevenue')
        .addSelect('SUM(booking.quantity)', 'totalTicketsSold')
        .addSelect('COUNT(booking.id)', 'totalBookings')
        .where('booking.status = :status', { status: 'active' })
        .andWhere('event.startDate >= :startDate', { startDate })
        .andWhere('event.startDate <= :endDate', { endDate })
        .getRawOne();

      return res.status(200).json({
        message: 'Revenue summary fetched successfully',
        // Q1 answer
        filteredRevenue: {
          period: { startDate, endDate },
          totalRevenue: Number(revenueInRange.totalRevenue) || 0,
          totalTicketsSold: Number(revenueInRange.totalTicketsSold) || 0,
          totalBookings: Number(revenueInRange.totalBookings) || 0,
        },
        // Q11 answer
        monthlyTrend: monthlyRevenue.map(row => ({
          month: row.month,
          totalRevenue: Number(row.totalRevenue) || 0,
          totalTicketsSold: Number(row.totalTicketsSold) || 0,
        })),
      });
    }

    return res.status(200).json({
      message: 'Revenue summary fetched successfully',
      monthlyTrend: monthlyRevenue.map(row => ({
        month: row.month,
        totalRevenue: Number(row.totalRevenue) || 0,
        totalTicketsSold: Number(row.totalTicketsSold) || 0,
      })),
    });

  } catch (error) {
    next(error);
  }
};

// ─── Q2 & Q6: ATTENDANCE SUMMARY ─────────────────────────
// Q2: City with most tickets sold in Q1 2025
// Q6: Average ticket price per city for published events
export const getAttendanceSummary = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const { month, year } = req.query;

    // Q2 — Tickets sold per city (filterable by month/year)
    let cityQuery = AppDataSource
      .createQueryBuilder(Booking, 'booking')
      .innerJoin('booking.tier', 'tier')
      .innerJoin('tier.event', 'event')
      .select('event.city', 'city')
      .addSelect('SUM(booking.quantity)', 'totalTicketsSold')
      .addSelect('COUNT(DISTINCT booking.userId)', 'uniqueAttendees')
      .addSelect('SUM(booking.priceAtBooking * booking.quantity)', 'totalRevenue')
      .where('booking.status = :status', { status: 'active' });

    if (month && year) {
      cityQuery = cityQuery
        .andWhere("strftime('%m', event.startDate) = :month", {
          month: String(month).padStart(2, '0'),
        })
        .andWhere("strftime('%Y', event.startDate) = :year", { year });
    }

    const cityAttendance = await cityQuery
      .groupBy('event.city')
      .orderBy('totalTicketsSold', 'DESC')
      .getRawMany();

    // Q6 — Average ticket price per city for published events
    const avgPriceByCity = await AppDataSource
      .createQueryBuilder(TicketTier, 'tier')
      .innerJoin('tier.event', 'event')
      .select('event.city', 'city')
      .addSelect('AVG(tier.price)', 'averageTicketPrice')
      .addSelect('COUNT(tier.id)', 'totalTiers')
      .where('event.status = :status', { status: 'published' })
      .groupBy('event.city')
      .orderBy('averageTicketPrice', 'DESC')
      .getRawMany();

    return res.status(200).json({
      message: 'Attendance summary fetched successfully',
      // Q2 answer
      cityAttendance: cityAttendance.map(row => ({
        city: row.city,
        totalTicketsSold: Number(row.totalTicketsSold) || 0,
        uniqueAttendees: Number(row.uniqueAttendees) || 0,
        totalRevenue: Number(row.totalRevenue) || 0,
      })),
      // Q6 answer
      averagePriceByCity: avgPriceByCity.map(row => ({
        city: row.city,
        averageTicketPrice: Number(row.averageTicketPrice).toFixed(2),
        totalTiers: Number(row.totalTiers),
      })),
    });

  } catch (error) {
    next(error);
  }
};

// ─── Q3, Q5 & Q13: TOP EVENTS ────────────────────────────
// Q3:  Top N best selling events of all time
// Q5:  Events with fewer than 10 seats remaining
// Q13: % of seats sold for events in next 30 days
export const getTopEvents = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const limit = Number(req.query.limit) || 5;

    // Q3 — Top selling events
    const topEvents = await AppDataSource
      .createQueryBuilder(Booking, 'booking')
      .innerJoin('booking.tier', 'tier')
      .innerJoin('tier.event', 'event')
      .select('event.id', 'eventId')
      .addSelect('event.title', 'title')
      .addSelect('event.city', 'city')
      .addSelect('SUM(booking.quantity)', 'totalTicketsSold')
      .addSelect('SUM(booking.priceAtBooking * booking.quantity)', 'totalRevenue')
      .where('booking.status = :status', { status: 'active' })
      .groupBy('event.id')
      .orderBy('totalTicketsSold', 'DESC')
      .limit(limit)
      .getRawMany();

    // Q5 — Events with fewer than 10 seats remaining
    const lowSeatsEvents = await AppDataSource
      .createQueryBuilder(Event, 'event')
      .innerJoin('event.tiers', 'tier')
      .select('event.id', 'eventId')
      .addSelect('event.title', 'title')
      .addSelect('event.city', 'city')
      .addSelect('event.startDate', 'startDate')
      .addSelect('SUM(tier.availableSeats)', 'totalAvailableSeats')
      .addSelect('SUM(tier.totalCapacity)', 'totalCapacity')
      .where('event.status = :status', { status: 'published' })
      .groupBy('event.id')
      .having('SUM(tier.availableSeats) < :seats', { seats: 10 })
      .orderBy('totalAvailableSeats', 'ASC')
      .getRawMany();

    // Q13 — Seats sold % for events in next 30 days
    const now = new Date().toISOString();
    const in30Days = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();

    const upcomingEvents = await AppDataSource
      .createQueryBuilder(Event, 'event')
      .innerJoin('event.tiers', 'tier')
      .select('event.id', 'eventId')
      .addSelect('event.title', 'title')
      .addSelect('event.startDate', 'startDate')
      .addSelect('SUM(tier.totalCapacity)', 'totalCapacity')
      .addSelect('SUM(tier.totalCapacity - tier.availableSeats)', 'seatsSold')
      .addSelect(
        'ROUND(SUM(tier.totalCapacity - tier.availableSeats) * 100.0 / SUM(tier.totalCapacity), 2)',
        'percentageSold'
      )
      .where('event.status = :status', { status: 'published' })
      .andWhere('event.startDate >= :now', { now })
      .andWhere('event.startDate <= :in30Days', { in30Days })
      .groupBy('event.id')
      .orderBy('event.startDate', 'ASC')
      .getRawMany();

    return res.status(200).json({
      message: 'Top events fetched successfully',
      // Q3 answer
      topSellingEvents: topEvents.map(row => ({
        eventId: row.eventId,
        title: row.title,
        city: row.city,
        totalTicketsSold: Number(row.totalTicketsSold) || 0,
        totalRevenue: Number(row.totalRevenue) || 0,
      })),
      // Q5 answer
      lowSeatEvents: lowSeatsEvents.map(row => ({
        eventId: row.eventId,
        title: row.title,
        city: row.city,
        startDate: row.startDate,
        totalAvailableSeats: Number(row.totalAvailableSeats),
        totalCapacity: Number(row.totalCapacity),
      })),
      // Q13 answer
      upcomingEventsSeatStatus: upcomingEvents.map(row => ({
        eventId: row.eventId,
        title: row.title,
        startDate: row.startDate,
        totalCapacity: Number(row.totalCapacity),
        seatsSold: Number(row.seatsSold),
        percentageSold: Number(row.percentageSold) || 0,
      })),
    });

  } catch (error) {
    next(error);
  }
};

// ─── Q4, Q8 & Q10: EVENT TIER BREAKDOWN ──────────────────
// Q4:  Revenue % per tier for a given event
// Q8:  Cancelled bookings + lost revenue per event
// Q10: Published events with zero bookings
export const getEventTierBreakdown = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const { eventId } = req.params;

    // Q4 — Revenue per tier + percentage
    const tierRevenue = await AppDataSource
      .createQueryBuilder(Booking, 'booking')
      .innerJoin('booking.tier', 'tier')
      .innerJoin('tier.event', 'event')
      .select('tier.id', 'tierId')
      .addSelect('tier.name', 'tierName')
      .addSelect('SUM(booking.quantity)', 'ticketsSold')
      .addSelect('SUM(booking.priceAtBooking * booking.quantity)', 'tierRevenue')
      .where('event.id = :eventId', { eventId: Number(eventId) })
      .andWhere('booking.status = :status', { status: 'active' })
      .groupBy('tier.id')
      .getRawMany();

    // Calculate total revenue for percentage
    const totalRevenue = tierRevenue.reduce(
      (sum, row) => sum + Number(row.tierRevenue), 0
    );

    // Q8 — Cancelled bookings + lost revenue per event
    const cancelledBookings = await AppDataSource
      .createQueryBuilder(Booking, 'booking')
      .innerJoin('booking.tier', 'tier')
      .innerJoin('tier.event', 'event')
      .select('event.id', 'eventId')
      .addSelect('event.title', 'eventTitle')
      .addSelect('COUNT(booking.id)', 'cancelledBookings')
      .addSelect('SUM(booking.priceAtBooking * booking.quantity)', 'lostRevenue')
      .where('booking.status = :status', { status: 'cancelled' })
      .groupBy('event.id')
      .orderBy('lostRevenue', 'DESC')
      .getRawMany();

    // Q10 — Published events with zero bookings
    const eventsWithNoBookings = await AppDataSource
      .createQueryBuilder(Event, 'event')
      .leftJoin('event.tiers', 'tier')
      .leftJoin('tier.bookings', 'booking', 'booking.status = :status', { status: 'active' })
      .select('event.id', 'eventId')
      .addSelect('event.title', 'title')
      .addSelect('event.city', 'city')
      .addSelect('event.startDate', 'startDate')
      .addSelect('COUNT(booking.id)', 'totalBookings')
      .where('event.status = :eventStatus', { eventStatus: 'published' })
      .groupBy('event.id')
      .having('COUNT(booking.id) = 0')
      .orderBy('event.startDate', 'ASC')
      .getRawMany();

    return res.status(200).json({
      message: 'Event tier breakdown fetched successfully',
      // Q4 answer
      tierBreakdown: tierRevenue.map(row => ({
        tierId: row.tierId,
        tierName: row.tierName,
        ticketsSold: Number(row.ticketsSold) || 0,
        tierRevenue: Number(row.tierRevenue) || 0,
        revenuePercentage: totalRevenue > 0
          ? ((Number(row.tierRevenue) / totalRevenue) * 100).toFixed(2) + '%'
          : '0%',
      })),
      totalRevenue,
      // Q8 answer
      cancelledBookingsByEvent: cancelledBookings.map(row => ({
        eventId: row.eventId,
        eventTitle: row.eventTitle,
        cancelledBookings: Number(row.cancelledBookings),
        lostRevenue: Number(row.lostRevenue) || 0,
      })),
      // Q10 answer
      publishedEventsWithNoBookings: eventsWithNoBookings.map(row => ({
        eventId: row.eventId,
        title: row.title,
        city: row.city,
        startDate: row.startDate,
      })),
    });

  } catch (error) {
    next(error);
  }
};

// ─── Q7, Q9 & Q12: ANALYTICS ─────────────────────────────
// Q7:  Unique attendees per organizer
// Q9:  Tier type with most revenue across all events
// Q12: User who spent the most money
export const getAnalytics = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const { organizerId } = req.query;

    // Q7 — Unique attendees per organizer
    let attendeesQuery = AppDataSource
      .createQueryBuilder(Booking, 'booking')
      .innerJoin('booking.tier', 'tier')
      .innerJoin('tier.event', 'event')
      .innerJoin('event.organizer', 'organizer')
      .select('organizer.id', 'organizerId')
      .addSelect('organizer.name', 'organizerName')
      .addSelect('COUNT(DISTINCT booking.userId)', 'uniqueAttendees')
      .where('booking.status = :status', { status: 'active' });

    if (organizerId) {
      attendeesQuery = attendeesQuery
        .andWhere('organizer.id = :organizerId', { organizerId: Number(organizerId) });
    }

    const uniqueAttendees = await attendeesQuery
      .groupBy('organizer.id')
      .orderBy('uniqueAttendees', 'DESC')
      .getRawMany();

    // Q9 — Tier type with most revenue (grouped by tier NAME)
    const tierTypeRevenue = await AppDataSource
      .createQueryBuilder(Booking, 'booking')
      .innerJoin('booking.tier', 'tier')
      .select('tier.name', 'tierName')
      .addSelect('SUM(booking.priceAtBooking * booking.quantity)', 'totalRevenue')
      .addSelect('SUM(booking.quantity)', 'totalTicketsSold')
      .addSelect('COUNT(DISTINCT tier.eventId)', 'eventsCount')
      .where('booking.status = :status', { status: 'active' })
      .groupBy('tier.name')
      .orderBy('totalRevenue', 'DESC')
      .getRawMany();

    // Q12 — User who spent the most
    const topSpenders = await AppDataSource
      .createQueryBuilder(Booking, 'booking')
      .innerJoin('booking.user', 'user')
      .select('user.id', 'userId')
      .addSelect('user.name', 'userName')
      .addSelect('user.email', 'userEmail')
      .addSelect('SUM(booking.priceAtBooking * booking.quantity)', 'totalSpent')
      .addSelect('COUNT(booking.id)', 'totalBookings')
      .where('booking.status = :status', { status: 'active' })
      .groupBy('user.id')
      .orderBy('totalSpent', 'DESC')
      .limit(10)
      .getRawMany();

    return res.status(200).json({
      message: 'Analytics fetched successfully',
      // Q7 answer
      uniqueAttendeesByOrganizer: uniqueAttendees.map(row => ({
        organizerId: row.organizerId,
        organizerName: row.organizerName,
        uniqueAttendees: Number(row.uniqueAttendees),
      })),
      // Q9 answer
      revenueByTierType: tierTypeRevenue.map(row => ({
        tierName: row.tierName,
        totalRevenue: Number(row.totalRevenue) || 0,
        totalTicketsSold: Number(row.totalTicketsSold) || 0,
        eventsCount: Number(row.eventsCount),
      })),
      // Q12 answer
      topSpenders: topSpenders.map(row => ({
        userId: row.userId,
        userName: row.userName,
        userEmail: row.userEmail,
        totalSpent: Number(row.totalSpent) || 0,
        totalBookings: Number(row.totalBookings),
      })),
    });

  } catch (error) {
    next(error);
  }
};