import { Response, NextFunction } from 'express';
import { AppDataSource } from '../data.source';
import { Booking } from '../entity/Booking';
import { TicketTier } from '../entity/TicketTier';
import { Event } from '../entity/Event';
import { AuthRequest } from '../middleware/auth.middleware';

const bookingRepo = AppDataSource.getRepository(Booking);
const tierRepo = AppDataSource.getRepository(TicketTier);
const eventRepo = AppDataSource.getRepository(Event);

// ─── CREATE BOOKING ──────────────────────────────────────
export const createBooking = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const { tierId, quantity } = req.body;

    // 1. Validate fields
    if (!tierId || !quantity) {
      return res.status(400).json({ message: 'tierId and quantity are required' });
    }

    if (quantity <= 0) {
      return res.status(400).json({ message: 'Quantity must be greater than 0' });
    }

    // 2. Find the tier
    const tier = await tierRepo.findOne({
      where: { id: Number(tierId) },
    });

    if (!tier) {
      return res.status(404).json({ message: 'Ticket tier not found' });
    }

    // 3. Find the event this tier belongs to
    const event = await eventRepo.findOne({
      where: { id: tier.eventId },
    });

    if (!event) {
      return res.status(404).json({ message: 'Event not found' });
    }

    // 4. Check event is published
    if (event.status !== 'published') {
      return res.status(400).json({ message: 'Bookings can only be made for published events' });
    }

    // 5. Check enough seats available
    if (tier.availableSeats < quantity) {
      return res.status(400).json({
        message: `Not enough seats available. Requested: ${quantity}, Available: ${tier.availableSeats}`,
      });
    }

    // 6. Use TRANSACTION — deduct seats + create booking atomically
    const booking = await AppDataSource.transaction(async (manager) => {

      // 6a. Deduct seats from tier
      await manager.decrement(
        TicketTier,
        { id: tier.id },
        'availableSeats',
        quantity
      );

      // 6b. Create the booking record
      const newBooking = manager.create(Booking, {
        quantity,
        priceAtBooking: tier.price,  // ← snapshot price at time of booking
        status: 'active',
        userId: req.userId,
        tierId: tier.id,
      });

      return await manager.save(Booking, newBooking);
    });

    return res.status(201).json({
      message: 'Booking created successfully',
      booking: {
        ...booking,
        totalAmount: Number(booking.priceAtBooking) * booking.quantity,
      },
    });

  } catch (error) {
    next(error);
  }
};

// ─── GET MY BOOKINGS ─────────────────────────────────────
export const getMyBookings = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const bookings = await bookingRepo.find({
      where: { userId: req.userId },
      relations: ['tier', 'tier.event'],
      order: { createdAt: 'DESC' },
    });

    // Format response with useful info
    const formattedBookings = bookings.map(booking => ({
      id: booking.id,
      quantity: booking.quantity,
      priceAtBooking: booking.priceAtBooking,
      totalAmount: Number(booking.priceAtBooking) * booking.quantity,
      status: booking.status,
      createdAt: booking.createdAt,
      tier: {
        id: booking.tier.id,
        name: booking.tier.name,
        price: booking.tier.price,
      },
      event: {
        id: booking.tier.event.id,
        title: booking.tier.event.title,
        city: booking.tier.event.city,
        startDate: booking.tier.event.startDate,
        status: booking.tier.event.status,
      },
    }));

    return res.status(200).json({
      message: 'Bookings fetched successfully',
      count: formattedBookings.length,
      bookings: formattedBookings,
    });

  } catch (error) {
    next(error);
  }
};

// ─── CANCEL BOOKING ──────────────────────────────────────
export const cancelBooking = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const { id } = req.params;

    // 1. Find booking with tier
    const booking = await bookingRepo.findOne({
      where: { id: Number(id) },
      relations: ['tier'],
    });

    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }

    // 2. Check ownership — only the user who booked can cancel
    if (booking.userId !== req.userId) {
      return res.status(403).json({ message: 'You are not authorized to cancel this booking' });
    }

    // 3. Already cancelled?
    if (booking.status === 'cancelled') {
      return res.status(400).json({ message: 'Booking is already cancelled' });
    }

    // 4. Use TRANSACTION — return seats + cancel booking atomically
    await AppDataSource.transaction(async (manager) => {

      // 4a. Return seats back to tier
      await manager.increment(
        TicketTier,
        { id: booking.tier.id },
        'availableSeats',
        booking.quantity
      );

      // 4b. Mark booking as cancelled
      await manager.update(Booking, { id: booking.id }, { status: 'cancelled' });
    });

    return res.status(200).json({
      message: 'Booking cancelled successfully',
      refundAmount: Number(booking.priceAtBooking) * booking.quantity,
    });

  } catch (error) {
    next(error);
  }
};