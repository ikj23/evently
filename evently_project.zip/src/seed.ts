import 'reflect-metadata';
import { AppDataSource } from './data.source';
import { User } from './entity/User';
import { Event } from './entity/Event';
import { TicketTier } from './entity/TicketTier';
import { Booking } from './entity/Booking';
import bcrypt from 'bcrypt';

const seed = async () => {
  // ─── Connect to database ─────────────────────────────
  await AppDataSource.initialize();
  console.log('✅ Database connected!');

  // ─── Clear existing data (in correct order) ──────────
  console.log('🗑️  Clearing existing data...');
  await AppDataSource.getRepository(Booking).clear();
  await AppDataSource.getRepository(TicketTier).clear();
  await AppDataSource.getRepository(Event).clear();
  await AppDataSource.getRepository(User).clear();
  console.log('✅ Existing data cleared!');

  // ═══════════════════════════════════════════════════════
  // STEP 1 — SEED USERS
  // ═══════════════════════════════════════════════════════
  console.log('\n👤 Seeding users...');

  const userRepo = AppDataSource.getRepository(User);

  const hashedPassword = await bcrypt.hash('password123', 10);

  const users = userRepo.create([
    { name: 'Raj Kumar',    email: 'raj@example.com',   password: hashedPassword },
    { name: 'Priya Sharma', email: 'priya@example.com', password: hashedPassword },
    { name: 'Amit Patel',   email: 'amit@example.com',  password: hashedPassword },
    { name: 'Sara Khan',    email: 'sara@example.com',  password: hashedPassword },
    { name: 'Rohan Mehta',  email: 'rohan@example.com', password: hashedPassword },
  ]);

  const savedUsers = await userRepo.save(users);
  const [raj, priya, amit, sara, rohan] = savedUsers;
  console.log(`✅ ${savedUsers.length} users seeded!`);

  // ═══════════════════════════════════════════════════════
  // STEP 2 — SEED EVENTS
  // ═══════════════════════════════════════════════════════
  console.log('\n🎪 Seeding events...');

  const eventRepo = AppDataSource.getRepository(Event);

  const events = eventRepo.create([
    // Event 1 — Mumbai, January 2025 (answers Q1, Q2, Q4)
    {
      title: 'Tech Summit 2025',
      description: 'Annual technology conference for developers and innovators',
      venue: 'NSCI Dome',
      city: 'Mumbai',
      startDate: new Date('2025-01-15T09:00:00.000Z'),
      endDate: new Date('2025-01-15T18:00:00.000Z'),
      status: 'published',
      organizerId: raj.id,
    },
    // Event 2 — Delhi, February 2025 (answers Q2, Q3, Q11)
    {
      title: 'Music Fest 2025',
      description: 'Best music festival of the year featuring top artists',
      venue: 'Jawaharlal Stadium',
      city: 'Delhi',
      startDate: new Date('2025-02-20T09:00:00.000Z'),
      endDate: new Date('2025-02-20T23:00:00.000Z'),
      status: 'published',
      organizerId: raj.id,
    },
    // Event 3 — Mumbai, March 2025 (answers Q2, Q11)
    {
      title: 'Food Expo 2025',
      description: 'Biggest food exhibition in Western India',
      venue: 'Bombay Exhibition Centre',
      city: 'Mumbai',
      startDate: new Date('2025-03-10T09:00:00.000Z'),
      endDate: new Date('2025-03-10T18:00:00.000Z'),
      status: 'published',
      organizerId: priya.id,
    },
    // Event 4 — Bangalore, January 2025 (answers Q2, Q6)
    {
      title: 'Startup Expo 2025',
      description: 'Meet the next generation of startups and entrepreneurs',
      venue: 'Bangalore Palace Grounds',
      city: 'Bangalore',
      startDate: new Date('2025-01-25T10:00:00.000Z'),
      endDate: new Date('2025-01-25T20:00:00.000Z'),
      status: 'published',
      organizerId: priya.id,
    },
    // Event 5 — Delhi, upcoming within 30 days (answers Q13)
    {
      title: 'Art Summit 2026',
      description: 'Contemporary art showcase featuring local and international artists',
      venue: 'National Gallery of Modern Art',
      city: 'Delhi',
      startDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000), // 10 days from now
      endDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000 + 8 * 60 * 60 * 1000),
      status: 'published',
      organizerId: amit.id,
    },
    // Event 6 — Mumbai, published but NO bookings (answers Q10)
    {
      title: 'Comedy Night 2026',
      description: 'An evening of stand-up comedy with top comedians',
      venue: 'Canvas Laugh Club',
      city: 'Mumbai',
      startDate: new Date('2026-06-20T19:00:00.000Z'),
      endDate: new Date('2026-06-20T22:00:00.000Z'),
      status: 'published',
      organizerId: raj.id,
    },
    // Event 7 — Draft event (should NOT appear in public listings)
    {
      title: 'Secret Conference 2026',
      description: 'Not published yet',
      venue: 'TBD',
      city: 'Chennai',
      startDate: new Date('2026-08-01T09:00:00.000Z'),
      endDate: new Date('2026-08-01T18:00:00.000Z'),
      status: 'draft',
      organizerId: raj.id,
    },
  ]);

  const savedEvents = await eventRepo.save(events);
  const [techSummit, musicFest, foodExpo, startupExpo, artSummit, comedyNight] = savedEvents;
  console.log(`✅ ${savedEvents.length} events seeded!`);

  // ═══════════════════════════════════════════════════════
  // STEP 3 — SEED TICKET TIERS
  // ═══════════════════════════════════════════════════════
  console.log('\n🎟️  Seeding ticket tiers...');

  const tierRepo = AppDataSource.getRepository(TicketTier);

  const tiers = tierRepo.create([
    // Tech Summit tiers (Event 1) — low VIP seats for Q5
    { name: 'VIP',              price: 2000, totalCapacity: 10,  availableSeats: 10,  eventId: techSummit.id },
    { name: 'General Admission',price: 500,  totalCapacity: 500, availableSeats: 500, eventId: techSummit.id },
    { name: 'Early Bird',       price: 300,  totalCapacity: 200, availableSeats: 200, eventId: techSummit.id },

    // Music Fest tiers (Event 2)
    { name: 'VIP',              price: 1500, totalCapacity: 50,  availableSeats: 50,  eventId: musicFest.id },
    { name: 'General Admission',price: 400,  totalCapacity: 300, availableSeats: 300, eventId: musicFest.id },
    { name: 'Early Bird',       price: 250,  totalCapacity: 150, availableSeats: 150, eventId: musicFest.id },

    // Food Expo tiers (Event 3)
    { name: 'VIP',              price: 1000, totalCapacity: 30,  availableSeats: 30,  eventId: foodExpo.id },
    { name: 'General Admission',price: 300,  totalCapacity: 400, availableSeats: 400, eventId: foodExpo.id },

    // Startup Expo tiers (Event 4)
    { name: 'VIP',              price: 3000, totalCapacity: 20,  availableSeats: 20,  eventId: startupExpo.id },
    { name: 'General Admission',price: 800,  totalCapacity: 200, availableSeats: 200, eventId: startupExpo.id },

    // Art Summit tiers (Event 5 — upcoming, answers Q13)
    { name: 'VIP',              price: 2500, totalCapacity: 15,  availableSeats: 15,  eventId: artSummit.id },
    { name: 'General Admission',price: 600,  totalCapacity: 100, availableSeats: 100, eventId: artSummit.id },

    // Comedy Night tiers (Event 6 — NO bookings, answers Q10)
    { name: 'VIP',              price: 1200, totalCapacity: 20,  availableSeats: 20,  eventId: comedyNight.id },
    { name: 'General Admission',price: 400,  totalCapacity: 100, availableSeats: 100, eventId: comedyNight.id },
  ]);

  const savedTiers = await tierRepo.save(tiers);

  // Reference tiers by name for bookings
  const techVIP       = savedTiers[0];
  const techGeneral   = savedTiers[1];
  const techEarly     = savedTiers[2];
  const musicVIP      = savedTiers[3];
  const musicGeneral  = savedTiers[4];
  const foodVIP       = savedTiers[6];
  const foodGeneral   = savedTiers[7];
  const startupVIP    = savedTiers[8];
  const artVIP        = savedTiers[10];
  const artGeneral    = savedTiers[11];

  console.log(`✅ ${savedTiers.length} ticket tiers seeded!`);

  // ═══════════════════════════════════════════════════════
  // STEP 4 — SEED BOOKINGS (using transactions)
  // ═══════════════════════════════════════════════════════
  console.log('\n📋 Seeding bookings...');

  const bookingRepo = AppDataSource.getRepository(Booking);

  // Helper function to create booking with transaction
  const createBooking = async (
    userId: number,
    tier: TicketTier,
    quantity: number,
    status: 'active' | 'cancelled' = 'active'
  ) => {
    return await AppDataSource.transaction(async (manager) => {
      // Deduct seats
      if (status === 'active') {
        await manager.decrement(TicketTier, { id: tier.id }, 'availableSeats', quantity);
      }
      // Create booking
      const booking = manager.create(Booking, {
        quantity,
        priceAtBooking: tier.price,
        status,
        userId,
        tierId: tier.id,
      });
      return await manager.save(Booking, booking);
    });
  };

  // ── Tech Summit bookings (Event 1 — Jan 2025) ──────────
  // Raj books VIP x3
  await createBooking(raj.id, techVIP, 3);
  // Priya books General x10
  await createBooking(priya.id, techGeneral, 10);
  // Amit books Early Bird x5
  await createBooking(amit.id, techEarly, 5);
  // Sara books VIP x2
  await createBooking(sara.id, techVIP, 2);
  // Rohan books General x8
  await createBooking(rohan.id, techGeneral, 8);
  // Priya books another General (cancelled — answers Q8)
  await createBooking(priya.id, techGeneral, 3, 'cancelled');
  // Sara books Early Bird (cancelled — answers Q8)
  await createBooking(sara.id, techEarly, 2, 'cancelled');

  console.log('  ✅ Tech Summit bookings done');

  // ── Music Fest bookings (Event 2 — Feb 2025) ──────────
  // Priya books VIP x2
  await createBooking(priya.id, musicVIP, 2);
  // Amit books General x15
  await createBooking(amit.id, musicGeneral, 15);
  // Rohan books VIP x1
  await createBooking(rohan.id, musicVIP, 1);
  // Sara books General x6
  await createBooking(sara.id, musicGeneral, 6);

  console.log('  ✅ Music Fest bookings done');

  // ── Food Expo bookings (Event 3 — Mar 2025) ──────────
  // Raj books VIP x2
  await createBooking(raj.id, foodVIP, 2);
  // Priya books General x12
  await createBooking(priya.id, foodGeneral, 12);
  // Amit books General x4
  await createBooking(amit.id, foodGeneral, 4);

  console.log('  ✅ Food Expo bookings done');

  // ── Startup Expo bookings (Event 4 — Jan 2025) ────────
  // Raj books VIP x1 (makes Raj the top spender — answers Q12)
  await createBooking(raj.id, startupVIP, 1);
  // Sara books General x3
  await createBooking(sara.id, startupVIP, 1);

  console.log('  ✅ Startup Expo bookings done');

  // ── Art Summit bookings (Event 5 — upcoming) ──────────
  // Raj books VIP x3 (answers Q13 — seats sold in next 30 days)
  await createBooking(raj.id, artVIP, 3);
  // Priya books General x5
  await createBooking(priya.id, artGeneral, 5);

  console.log('  ✅ Art Summit bookings done');
  // Note: Comedy Night (Event 6) has NO bookings on purpose — answers Q10

  const totalBookings = await bookingRepo.count();
  console.log(`✅ ${totalBookings} total bookings seeded!`);


  await AppDataSource.destroy();
  process.exit(0);
};

seed().catch((error) => {
  console.error('❌ Seed failed:', error);
  process.exit(1);
});